package javafx_forum1.gui;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx_forum1.entities.Publication;
import javafx_forum1.services.PublicationService;

public class PubsController implements Initializable {
     //@FXML
   // private TextField userTextField;

    @FXML
    private ChoiceBox<String> choixPub;
    @FXML
    private TextField User;
    @FXML
    private Button btnADD; // This is the "btnADD" butto
private PublicationService publicationService = new PublicationService();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        System.out.println("Initialize method called.");
    
        choixPub.getItems().addAll("Yoga", "Footing", "FootKids", "Meditation", "Karate", "Musculation");
        choixPub.setValue("Yoga");
    }

   /* private void ajouterPublication() {
        String username = userTextField.getText();
        String choix = choixPub.getValue();

        // Créez une nouvelle instance de Publication
        Publication nouvellePublication = new Publication(username, choix);

        // Appelez la méthode de votre classe de service/DAO pour insérer la publication
        PublicationService publicationService = new PublicationService(); // Assurez-vous d'initialiser votre service correctement
        publicationService.CreerPublication(nouvellePublication);

        // Vous pouvez également réinitialiser les champs de saisie après l'ajout réussi si nécessaire
        userTextField.clear();
        choixPub.setValue(null);
    }*/

    @FXML
    private void btnADD(ActionEvent event) {
         String username = User.getText();
        String choix = choixPub.getValue();
        

        // Créez une nouvelle instance de Publication
        Publication nouvellePublication = new Publication(username, choix);

        // Appelez la méthode de votre classe de service/DAO pour insérer la publication
       // PublicationService publicationService = new PublicationService(); // Assurez-vous d'initialiser votre service correctement
        publicationService.CreerPublication(nouvellePublication);

        // Vous pouvez également réinitialiser les champs de saisie après l'ajout réussi si nécessaire
        User.clear();
        choixPub.setValue(null);
        
    }
}
